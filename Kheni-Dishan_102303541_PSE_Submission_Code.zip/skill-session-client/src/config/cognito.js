// Cognito User Pool configuration
const poolData = {
  UserPoolId: 'eu-north-1_SzARU5mjS',
  ClientId: '2bq6ks2m10khikpotu3284o1b',
};

export default poolData;